﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPSample.Model
{
    public interface IMyModel
    {
        string GetMyLabel();
    }
}
